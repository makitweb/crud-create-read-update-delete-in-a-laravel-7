<!-- Extends template page-->


<!-- Specify content -->
<?php $__env->startSection('content'); ?>

<h3>Subjects List</h3>
   
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">

        <!-- Alert message (start) -->
        <?php if(Session::has('message')): ?>
        <div class="alert <?php echo e(Session::get('alert-class')); ?>">
            <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <!-- Alert message (end) -->
           
        <div class='actionbutton'>
                        
            <a class='btn btn-info float-right' href="<?php echo e(route('subjects.create')); ?>">Add</a>
                        
        </div>
        <table class="table" >
            <thead>
                <tr>
                    <th width='40%'>Name</th>
                    <th width='40%'>Description</th>
                    <th width='20%'>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subject->name); ?></td>
                    <td><?php echo e($subject->description); ?></td>
                    <td>
                        <!-- Edit -->
                        <a href="<?php echo e(route('subjects.edit',[$subject->id])); ?>" class="btn btn-sm btn-info">Edit</a>
                        <!-- Delete -->
                        <a href="<?php echo e(route('subjects.delete',$subject->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
            
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/subjects/index.blade.php ENDPATH**/ ?>